<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Formularz kontaktowy</title>
    <link rel = "stylesheet" href="css.css">
</head>
<body>
<div class="Formularz">
<h5>Formularz kontaktowy</h5>
<ul>


<form name="formularz">
    <li>Imie i nazwisko* <input type="text" name="input" value="Twoje imie i nazwisko" maxlength="50"></form></li>
    <li>Adres email*<input type="text" name="input" value="Twoj adres email" maxlength="30"></li>
    <li>Telefon kontaktowy<input type="text" name="input" value="Dozwolone znaki: cyfry, spacje" maxlength="11"></li>

    <li>Wybierz temat : <select name="wybierz temat" size="1">
        <option value="1" selected> Wykonanie strony internetowej </option>
        </select> </li>
    <li>
        Tresc wiadomości*<textarea name="text1" cols="2" rows="10" wrap="hard">Tutaj wpisz tekst</textarea>
    </li>
<li>
 <legend>Preferowana forma kontaktu</legend>
        <label>E-mail </label><input type="checkbox" name="radio1" value="Przycisk nie zaznaczony">
    <label>Telefon </label><input type="checkbox" name="radio1" checked value="Przycisk zaznaczony">  </li>

    <li>    <legend>Posiadasz juz strone www?</legend>
        <label>TAK </label><input type="radio" name="radio1" value="Przycisk nie zaznaczony">
        <label>NIE </label><input type="radio" name="radio1" checked value="Przycisk zaznaczony">

</li>
   <li>
    Zalaczniki
    </li>
    <br><input type = "file" id="zalacznik", name="plik"></br>
    </ul>


    <input type="submit" name="sub1" value="Wyślij formularz"></form>
</form>
</div>
</body>
</html>